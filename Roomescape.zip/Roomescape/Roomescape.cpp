﻿#include<bangtal>
using namespace bangtal;

int main()
{
	//1. 장면 생성한다.//
	auto room1 =Scene::create("룸1", "Images/배경-1.png");
	auto room2 = Scene::create("룸2", "Images/배경-2.png");


	// 열쇠를 만든다.
	auto key = Object::create("Images/열쇠.png", room1, 600, 150);
	key->setScale(0.2f); // 열쇠 크기 20%로 줄임. 콜백에서 열쇠 주우면 인벤토리로 가져오도록 설정.

	key->setOnMouseCallback([&](ObjectPtr object, int x, int y, MouseAction action)->bool { // 파라미터 잘 몰라도 괜춘...일단은 사용해보자.
		key->pick();
		return true; 
	});

	auto flowerpot_moved = false; // 화분 이동되었는가?(2)
	// 화분을 만든다.(1)
	auto flowerpot = Object::create("Images/화분.png", room1, 550, 150);
	flowerpot->setOnMouseCallback([&](ObjectPtr object, int x, int y, MouseAction action)->bool { // 파라미터 잘 몰라도 괜춘...일단은 사용해보자.
		if (flowerpot_moved == false) {
			if (action == MouseAction::MOUSE_DRAG_LEFT) {
				flowerpot->locate(room1, 450, 150);
				flowerpot_moved = true;
			}
			else if (action == MouseAction::MOUSE_DRAG_RIGHT)
			{
				flowerpot->locate(room1, 650, 150);
				flowerpot_moved = true;
			}
		}
		return true;
	});

	//3. 문을 생성한다.
	auto open1 = false; // bool이라고 써도 되지만, auto 쓰면 알아서 컴퓨터가 bool로 해석함.
	auto door1 = Object::create("Images/문-오른쪽-닫힘.png", room1, 800, 270);

	//4. 문을 클릭하면 이동한다.	//lambda function
	door1->setOnMouseCallback([&](ObjectPtr object, int x, int y, MouseAction action)->bool {
		if (open1 == true) {		// 문이 열린 상태. if문 써서 열린상태면 끝, 닫히면 열림으로. 그 열린 상태를 open1으로 변수 설정
			room2->enter();
		}
		else if (key->isHanded()){						//문이 닫힌 상태
			door1->setImage("Images/문-오른쪽-열림.png"); 		// door1이 포인터. -> 이게 호출하는것.
			open1 = true;
		}
		else {
			showMessage("열쇠가 필요해!!!");
		}
	
		return true; //인라인 함수. 마우스콜백은 입력파라미터로 입력해야. bool로 논리값 리턴됨.
	} );

	auto door2 = Object::create("Images/문-왼쪽-열림.png", room2, 320, 270);
	door2->setOnMouseCallback([&](ObjectPtr object, int x, int y, MouseAction action)->bool {
		room1->enter();
		return true;
	});

	auto open3 = false;
	auto door3 = Object::create("Images/문-오른쪽-닫힘.png", room2, 910, 270);
	door3->setOnMouseCallback([&](ObjectPtr object, int x, int y, MouseAction action)->bool {
		if (open3 == true) {		// 문이 열린 상태. if문 써서 열린상태면 끝, 닫히면 열림으로. 그 열린 상태를 open1으로 변수 설정
			endGame();
		}
		else {						//문이 닫힌 상태
			door3->setImage("Images/문-오른쪽-열림.png"); 		// door1이 포인터. -> 이게 호출하는것.
			open3 = true;
		}

		return true; //인라인 함수. 마우스콜백은 입력파라미터로 입력해야. bool로 논리값 리턴됨.
		});

	//2. 게임을 시작한다.//
	startGame(room1);


	return 0;
}